id#name#description#height#width#resizing#auto_resize#resizing_use_cookie#resize_horizontal#visual#accessibility_warnings#wysiwyg_enable#blockformats#fonts#use_custom_toolbar#toolbar_row1#toolbar_row2#toolbar_row3
inc#str#str#str#str#str#str#str#str#str#str#str#str#str#str#str#str#str
#################

1#Editor Group 1#This is the description of editor group 1#350#100%#1#0#0#1#1#1#1###0###
2#Basic#This is a very basic toolbar.#400#100%#1#0#0#1#1#1#1###1#styleselect,bold,italic,underline##