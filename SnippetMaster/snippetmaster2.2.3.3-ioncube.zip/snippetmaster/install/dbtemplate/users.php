id#username#password#first_name#last_name#email#enabled#start_root#start_url#language#allow_uploads#user_type#list_group#upload_group#edit_group#description#manage_files#disk_quota
inc#str#str#str#str#str#int#str#str#str#int#str#int#int#int#str#int#int
################0#
