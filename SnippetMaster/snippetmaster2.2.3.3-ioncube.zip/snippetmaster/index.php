<?php //00acd
// Copyright (c) 2001-2009 Electric Toad Internet Solutions Incorporated. All Rights Reserved.
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('<html>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	text-decoration: none;
	text-align: center;
}
div#container {
	margin-left: auto;
	margin-right: auto;
	width: 760px;
	text-align: left;
}
.boxerror {
	background-color: #FFE1E1;
	border: 1px solid #FF9393;
	font-family: "Courier New", Courier, monospace;
	width: 720px;
	padding: 5px;
}
-->
</style>
<title>Ioncube Loader is not installed</title>
<body>
<div id="container"> <span class="boxerror">Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.</span>
  <h1 align="center">Ioncube Loader is not installed</h1>
  <p>This program file is encoded -- in order to decode and run it, your web server needs the Ioncube Loader to be installed. </p>
  <p>Most web hosting servers are already configured to run the Ioncube Loader, however it seems that your server is not correctly set up and has a problem. Don\'t worry -- it can be easily fixed.</p>
  <h2>What is the Ioncube Loader?</h2>
  <p>The Ioncube Loader is a free, industry standard program that runs on your web server. It is used to decode files like this one that are encoded with the Ioncube PHP Encoder.</p>
  <p>If you are a do-it-yourself person, you can run the <a href="ioncube/ioncube-loader-helper.php">Ioncube Loader Diagnostic Utility</a> and try to fix the problem.</p>
  <p>Otherwise, you should send your web hosting provider a link to this page and ask them to fix the problem. (It should take them about 10 seconds to fix it.)</p>
  <h2>What if my hosting provider will not fix the problem?</h2>
  <p>There are no technical or security  reasons to prevent the Ioncube Loader from running on your web server. If your web hosting provider can not (or will not)  fix the problem, then you should switch to a more competent hosting provider.</p><p></p><p></p>
</div>
</body>
</html>');exit(199);
?>
4+oV50P8ha/R31DWjf8xR5OS2An3w7Ac2pQ6QvIijBdYTmlgKou/kyTIkLRMGt761YYWQB/RYgKJ
J61FIALpkLRA2oM3JVzICLrKZJHKr7BHlDi6D2Vi244Dk+9LrIRhYv5w0Qm93DnELyTLdS+gDL0V
Qf/FbTcKcAgS9uQSgbpXm0X8msUjGCy5ODeIybGwx2N8yf6y6rkMlZVxCEd6nuu3jFpuSuRbGN9w
+OvBZVOrWhHG8w/IEiYdfnmFY65ew2eqAhrTJemVKfPVtnJOM5u425xDIbAovH9wz5+Vvm9rixyG
HQAPN4Jh2J41wEbK8m6PvyI1KmtTkcQRS47z32Rh6+cjVxq3OL80eFH+qIuHbTdfCmJk1H300Xfb
UChq/L2Eb4a6MCCj+l6NDwDLy6fC9S/inThCB1D46j+V4gPmV13DjpsdwGrkdhTF29LS4jHCSPGj
gi6UPMjRtXyj4d1udPiKFZb/eGTOnnRvc0iP/duKBNcAfL1loNdKIXmHJTkR3Td8zM8WSrAr77xm
He2uim93Rid+m4kbTNLStbqVMqsNuw9pV7+Sq3xtOMMj6EEKDP+EMZ7VMA05B+5CDUWP0/XDfSDm
u5M0xAr5MsUQxtyAb1PUXvjAGq6noLl/J5TvuewhKvYr939F45dQvaZDaLezG1jtGs+zJjLuqRv8
NuQZnPDym8PRJwIQmrvZi6z6FT45UXwQvTWdF/SELIeFPhalrWWR4toliyoMGcgDP7NejbRGjNlO
Yma+W4s5Riu4P8MvzIibKRUJoizuUgJyXZTeG/hXQ53opVDBQR+XadzZx13dQrCfC1lPZdr4o68M
GDdWvzRBw+ea27wMFdXKz1Z4UQ9qHPz2D2oWedg86tfEqGH5LPSi25/hYdec+WRm9tv5egKsIwD6
L47oeXHhc7rBGIxD6oAjzvNRvy1GVQbep0NBi90/a7yaweaIhUnSALiob9t412RRjdWG3FyNVKc2
ugnZO8MwVfCW1DXNESi+Y++Um83LrKx78fetdS5sPN9efIM+NTWxj6W8XYtY69J7GI7ww6Ww/4NB
EDlS8Iovsk8t56v31/GW5B2yahKxWK7CwuQgy+jWuzx/taKvnobeqIt1OB79Os0Tj9oyGr/RpWyJ
lrskhCw7TGaf2mvymFVFfBSqLnXhfPtKLLbKwd561iCGN49OAbCqYakK+oPqBSGYV9Ys9MFoacC2
5xAPvT398lm+mGAGpC7iVr+Nvf27EnfjQb9zmgp57+CaXjGgf0jSJ5vx92WMKDRuNXfWbHogcBLv
bycX9N3uA0DKSdOaInB9EoGcX1YGBC1bTGLb1BcPJww4ja+7LNvoBeDCsYRPY4AYpsC4PBYO04L4
c80V1Td9m06ey/EqIViQachaevTlt+f6/Xh5WE2LSgRRQfC8NaXjebybgFEnTLlWlf8XUDpHefc8
sOBaw95JZrFDIkhuAgFz5/oWNUJ2ydu2IExzSeKhJq157nwqpx40V03cBWWWuOH3SwIq3na1S/Vw
Cf8iOSg/7cG+fsa2jaZTEAiBjHtXIhVUgHHtAuUPIiQyyC9m2z4+ZuDcI3ERNrD/1hpzDLulDwAX
WoD2hTSDNH+3gP6JliozeCJfYBkiRmJdfqMXczq+xlRTiJkLKWzB5mR0Yiu5o2BAQsGN5OhEfPp7
trR/PIrm77tjC6j2Jo0UBDWavTq/oTIKw7JlgJVDUToHHa/6/qJCGxOl4UQnb4V3oU3w4rzqeDMn
itUUxHbRfJ45Rht+hl1OGd83ZsslU/V7ZH9Rc+e/ZNAN85ON3G+ugpZEumeTNeqzh7VrqJOCS6h0
9VqUTBJYdUBv6r+6LYl6K4Wus5+D/Isfd63IApVLLi6zAd6Svsza6q2CHtCFPlzP6uD8/4FjZPAs
oeWMrSEJNbUwP8xO1mjLuR+V/f/l71XKBNkj8JBaHbJKQt4UK7jxFkX/guTJcTXUv1dOquATfUFw
njGeXhkKHO2hkS1HLNFU+zI6AKgzlov9iAZ4Tc0h1nDM4e+MjlXHEglZKBjw8ARvxrlrXpbVwzy9
2D+rhYu6YWpen33OAIYZ6xPxJZMPWWss/cKxKOQblaPbT77C+xl4vOZOP8SQX76usctoUHqECrbY
YmKRXRX4eiiWqb2SY/hCznOLh2UJxhysNfhvthfLvJdTW83a7pN+CIBU+cIbmIOej37QQ+xe1pJr
5BSQxhPeGFJ0HIbfzmRF8+b9wTXO2fzXqmRB8p55H9Kpz4OKSieqf4x8ge5yuRpQxIy+WDQq74zL
wpbFSk4t9mafniHmlieZQDRet9afZc41TPUgQd+4DtmRUwFdEQl+SpRS+3AKR0ZUIGJzNblo3f/x
X714KarxOeNP94r5AwoeW6qM8ZwdgxJ5He82UxBco80O8iGN+IPLOCzp6OV3394dSvh1IlwtezHO
qyc/6KCbIZRAxFMl6tp7TadGWj5DwvSj2z8prC4CBmSMN8wQOB7BKUdYQsQZoNj0c/Pp61wM4Kpb
IcxICENftqTrD7DAFsWJW2JEB9FVEpQgSVC5yh4NUx13HbKKtN7UyrQsa7NPHY9St4sme8L4YTKJ
UuFlYvSQZrHiYWkvIEiTNVEdOvER+ovClz/bnWd6tSfpnuLvjAyraaaYukCgNcGsYpBeKvA/SeTV
X8sWHC5+0Jlw5JefO5Xypd7by7smGf+U1I4mTx00CrhvdEyuf4/UthMj1H0GZtBYVI+SqKozxRHN
CEFvjf0zCHGRrU4Da07fgwk6bNFA+vMH+DO9kf7T0jb3Q0Q+/kdDf3OTtiO/bgmgpBsJmE+xdKNt
ZaUJmBgJVfUvxf4CutPekeQnvsn1raDVmqAM0YmblnOO5cS6Zax+0ZjQfrIbXolx1S4MkZrCj+QD
0W1H9mldXvpHx2lQ6VoiryGuTdqLqoDppyvVt5md6bIJTUUPTxGGbY/c72OY3EkaDOxTczZJu/A1
tJ0KJ5h4XMR2VMd04yvJ3zXjCzM9p8KIaa/1VQVpn4Tyg21s0pWbDHeFRYYGJLTrlT8MbjC2IeMt
5WbcP4EmF/9KqQR4lw/jkT6PspL5Olye+iLudOpCCUymJ1ZQFJsorNfzCHRFfoZnfvFnHtaIY0wK
zECaj71Da3SQJjS4hjo2ITuWr1DB+skkQvsFvYTZdgSGlrTKJClr2lvw7e2+ZJLuEYkauiBBfEOT
lRFlppKBMlroYPrkenCmuoBFIl16BpxNpSofIIxFcnUo0OLqfvP+sjQSg377bt1nlc4/pdLFmtXg
wOt677fR2DZ0SIsTlWr1/jUYFIIGVHxxmqtopgTOuYyddTE1WKni3ZwtAjdVqnf4dYYU+m9sUzZj
XIPRXn+WDBfvT/wnTS9+kUp14adxR16/FkhKaav1uaAQVp0joyzwE7A85VpIBJk0gjWBAqdRc3XB
kDcprbV04MLdv0K/mALnxocZa0INpz4Bzlbl/jTO5B4RnacNUVsBlnTU271D72R216prpOVlecUV
kmfTVhLih/q/AqY0Xh/QPmqgeuZSycIKCVa64r5FnypzLPxnUEyHAvhkR7KTHPWa7TCqpYOXOLrl
26S1r94ElVSkA9m3dPjrcap6FINYjfUn4dJgH3GNHKJTI/CFf3wFOye2YTz+GcB4HKt5dXHf9CAG
NDd4PZXI9a7ud+HSiXCdVbWkLKRq3Ujj1ERKQ2v0ZWj36MIcXqMRamrsNj4uvTyFHdbjMQc+tGTJ
seljSIG8mjoXk5wilO7OHgEmNG2Lebs2b+bhq6C6wVmSg/wnW/aW+3Pi9Yq2u+sCBYRHXoh3W1zY
wUbamz/qgwU92/HY/8XiJUmt+r4o2rnPUl/0oreniJ9b0eEk2QGTOM4RXhBLnzw68PG6LCrTC6eM
xdJJ1UBBChnI2E1IYrhS6XYpC/oXRueb6ytnHsFFUypS/UFKAU0iGAB5aC4e3txMlDdy/6kru4yK
xXjxmMiPH+yI1rsjJel4LkLCk4R6tIO9Q0vegC2er2KOIxMXHBaU0d0JNwAffDE5gNOkyA9rHKwC
rUhhMwTTRYYYmR5kmIEIQ1wbPQZBogao7JUo8NQ92AXOUvDlKQ9F83Gu+NLaZTBK7nbjeXt5DJ1R
cKg6KI46JMIKly0RSw/Dik6BTyMnut9DdU+p7ZkYG00EBgT5/NwHhoRN/8JkAv+1qFPnGsHEcJZ0
FbBqdTTeWT88J42xcNEb3oGJkfHYpex4Y+jUE7E8lRAdK1KtwzmMRpkDltdVKG5qD+LnRrxzmj66
ZBv3c/2quibQvm4JJt0Z8wJyCHQ8ErHiSZ9sFLJ23G5TCYvmhymJvqDZ0uqvujtzLQBgleiUgqh/
vN3Qb3Plptke++eIC72ZXH5RAbXbXhGJot+0cTx6A5OLZqtRIC+kG7Tl7+qiGZQTqLxgsm8DApjO
CLXnvDgMV98AwW6p2Kr7MKLB2ClYEHFcfrVivFU62Hq5nLM8XoCavPZcbMJ/AO+ngmP8LE0YhQXw
c6P0lYN/YTl36nlW/8JRkXqxtXWbJKP1KMdqJnYhQ+UE3208ALWEzCaR66bJwOlv896GHFokCm6s
+Jqhdulo3eBiwV5WOpjI7nhdN2IakDfiRdDx4aHbfeV83W39b3Qty33ys16CFwxYjpuVUy26ZrWa
V+Gd3Px9sfo4X4p6bnrkSmfbRWHOufHPDzExe9p3iemBC5hkgfuMgl1NLIKLYxZhzwYt0vimHs2n
rek38UIcM8XtcoTYYS2giOSUzOnFpc8ODYlyXtpRn3seOOnqbKfat5k4mouPXpaZwydx9EbEKUg6
Jk/r5cOcHuSJHaZZOcJ//IX2G5tYMpFOhyC2fD48y17plUFQqM0v9I9WygbRCCxmsQMMRRa9nUPz
Lmg4LPSvdefYX0iKNj9++L8DnP460VD0fBruVlChgDpJSQCoQ1Zuv0hp7ntWPfrLsUvSTlFNIbOT
YS1p9DLklie4Kw2eioZGg6UJGNOoZpDKibYGK8zE0e+Zycq2VNsfMVOxMXidecRUpa3Amy+CNTsM
FNRQxm/FJsDLWSdeDm2Fdt+DEJg0+MylosJlpWePGfMGsavhfqvc/jFDB5GJQGhIJru7ZSBzSdg9
ms4/bhWvvaKwdfUxtP+aGtA+19vaGTEJze6t4THHsxwBz/9r8VlfrchI6ubuk/dtwUDb4C2C2EWS
yF6MC1FHekCl0x7DZ5rbus+TCkkvb0qq5i/zWStA4Bh8+VEE6B66zjfM1QeR4KKBFVUIaifRHn4p
NNLqJ2FkMFUJGTIQNCuKPfRn/1YIhP6ogxN9YngzjGVIeaEluGd4rapWrQl4la+uBj1S7I08uvqU
q5LHj93D0pfDG9lyHK415uoK4D71puTBS3CBPQJcEE8WkislidZYRuwT5f9W+4ITARtRNk2hZlfz
UIzsrosRm0xyD63ea2/3sZw1x/E0GeLz7ZCgdsq5LGVJG34DqO4PRU3IAYW/yxtkwg6TlugOfUdg
Lo7V1lGnXdw+6i/2r45WUnFdJO9J/z0uy1NFttPtpVhIVOtQQpe2nR5IGOIzVvbMluCYVkDUU3KI
wYn7BqaDYQsC9YMlwdC9MLTUug6mvYr6wdkFihtf364Z2+TlGmgJrq2B1DuAs1t8fspF0fJ07PUf
4XrgERpIdxkid46p2WCot3MWv5U030fYdd87tZjK5DRPTz5zY1eYTa5QHtGha+8L6hSJdpRW1aUT
O+APtcaqci+Oh5NdobfXrw8QoF1Rd7RtL73HsHXbglDrpnGL5TcAVPKDNvWZh0vL/v39qaC0hsR4
BDTgVkD33U5SX+4SKR4+wtaNAmKf+Q6pfbw89/Aw94OaX3MYJCot0JMax/cyn5XRAt//bs5Mnd1p
f56A1xnVkEY3NeVusM3iaZFoFuD0qUnpzpj69/nrxnWRmk8F9p3UuYlnczGhLmhlM0aMjkCb6WBj
mAK6id7kXWkH6FNpsumk7kQHeXRCk5VO+/PD/IG8caD19rvZFmHMlOYLItQ+pTgmYpqK+ALdK2Fa
ZefokSxjsTffdGrp4pAT39ZbK2TTzEyOmgiaRAW8a2hhsN7PoTpmEMVj/81v1zZ402avf9FlAjRC
UuxDPwEG9rE+yICzzyNauiVJUvgygZM/s5Il6sGHKHU2asObrd0A3ZAEQk0dNtWGlGnmWa4SOA5S
T8M4Efsn/irjfmBu3cYsXrunxiZTGD3tjtQ4rwjefkZ08KVjuV+DR/C+nXXkNwQPzDsy310fvYm6
PxVCfCFPNdtNvNVQ2ZST0/Pk1bJO9X7URj+TmuxQhavZEOZg09P8T6vK2+7c4KibXKQXDC3D4oMX
ogNEDy2cr91a3p9b7dfYWCVvLdyREdtkSiV4LgD0ia3E++p/rf36RyecUv8AK9fqw0Tg4tK1rD3I
tOIaFtNmw0ZQPVePUflyXVB2x73EqdClwic1QPbGZZuZeoB2zfgWauGafehaiywqO8OAJyItYbkt
UJ7qW0erBiz0VOEg+HDnJO5P1P2OMAGfJhfUYjlw+zBHB+BmCgLWjLXCAMlCfgStfsvjQzGF//iM
eIGzTFFNKm9S1Ghf+BKvgZznILUvk1nKurzQK91hmY8hauB1LdQmJWfX2cQ2B9gqXHslV3Vwb/08
EAaa6hO42DHJvPhlBpK5qB9i/LNuOJhAvKUyNsi1CfILSsETkD9ujxt7lJJOrwA2aSrZ5C2p169G
iVTEKqC8QCGvIig5BvCa7DPJaGSkucWBeiVAkGAaUGptb4ozP2sZyy56jK3uDW84EDRm3I2pMdO3
SQ9kIWbYX4dVsHZP3Dt1dFgua/OfeQ7+98ExX+ttYOcmu6tv00INiuPR0MF+Zl46dlrTPfMzrR62
Hi6oPCgjEd6JhjdLlsyfDMrINLEeTSABlnUbzweVZnfohI3Ho9mhvG0eOTmO5z6lY36Ol236Sk3v
Mwjtf2dmS+bfbUwWBountPApncJ/GtCnRAYuzUqEpgO3JmCQzPrmjA76RefNBdMjQ8WYzoDtTZao
u4G+UIw5YZgH0uS5oeSHEP9cAqejGCvBq/DlDzWso7eKxYEXBe1vC9sLYo3/VfYtg2lQbYL6Lgfz
vlua0epj8QtlBsnPo9Q3+6UdycATb+j/MI4AMh6Di3uHjLdRj9NXOqNvc1ycsRrG8CJuDajbcngT
7e1cuJMcuktp9e+6OYt4KIOYaPRU9Me+OoHO/rXO4lnp/JP+nWDzzVa5Bxc9PwPAW2XwByLJPrg6
QNpIsAUHQZ72uox/CHFILcFWRRPBLD5HecEt1/DofWowpw1c+Ze6OjXJ1lAP38uAXb5tyCtJPDKV
w2SE9ozmhQWwxePJ9NW9tHYajQJ5CU7n0hKvA/+CLn7hs0fbkiwu5ToOi44qwKWDWyQJG11XETCq
4FVOUFIBbxwggKvLYGH+Dy5fiOZPEwUdz+mPAiakfod2y+F9k2wOXiBs10YOZB150hMbHuE4mzwv
dNALSD66EBvo4lEZAgsUzrzAGBNn9Kaf+Ltx63FQG6D5ae6ml454b4AlXRJfNlWOV8oviy3fYzEA
e6KVHY8BLefnVqxB3uuYiCCpfDQ9G16T/taaBiVsS1sHcQnYVfbihptFamGuS6PQKWw1WPhZ5u5M
s4M8TVEU/aDCpsnvVNHKhrLeRCPcLEzy0ySwsdeTVJMTD8I5rENeC6jvCpwg/5vmMf+/1R0I7TsX
wFroHycivTQk2a8raJx5m6eOocntJRH4cIbgMv4s306syWZB9ms5Vdx7CM2O+cuFc88VQO1Jbaj5
xeaUdFPaL4v1G7sJbUWEY8JIvoj34fMcLBSAsaLZ87fcAPvVyWH1b6zgcADcrZ1q3nL1YIhdUWO2
CF3TxiyKy09mwDewFrHd1AbHnnHz2KzEgzus3NCqgrvQKAahQw40OHkeEwL3hM30W6/yyJllnRZC
kOXYraa5jGDzjaJ/+qkYkHeAuQJxCpgWNOF2VpBRQjbGtjGVky7aRBl1NOM2MWfeWe4WlGMU0Tq3
+2z1cTxO9lxZgGYKIu/ZPkNWm5Xn5wZ2onhQJKqqyCJFBVc3pOxnk/QWBkonzT4cPMbr8KRHOykz
PFH4pZ/+0DlSIVxv+YafG/U644ZbXlR7a/ApvBdc7O2y8tKS4klpHREfC3adny9MBE0mrZun2Yyx
bGHNyO2G8qSYKHsPxfARjHkYaovLl9id44+r+10LYM6jHeW4oMZ2IUCigtaS+ywwQag5jz5K0avu
EkNdvieYfHWEP6FG1HB31uJ8CWPW2h2+RpJLW42SdfPG/E4XLotbTWJhIR3UbiHC5kWM3/V5Fp6U
fg0eAdi6mnFAOegu1noCB30D+mAlu/jBzaygORJ5ov3A7jNjUXlS5vOE4i5+z5jh+AQUuHlW6t00
jd3k0OK3iVxQX6vnVufy4CGGgCsxZy/f29CBaFK8SlQNlKFF/fikfg8Efd/izBHko0z4lkNHEjgz
I4/WQNdsTz9j/5I7zatLAR3F4egiAoHELSYbStcaI1JQTmgsxA1AGpGvKV8HFXmZVo0Pv8rXOtZM
OC7lzAzpDm67M1hh/GH7Mvtb5Ry9jXxsGz0Y2hbwCLERfJgbjG+MeU7h7RD8VYe2g+rmlZU4uG3K
zGqlAvNhx101WVneDUhO+h30NNea7OkmDZwnL6rQgjyWQ/iD4nrdn6U8FOM1hbOOOvYdX5bUPxta
2+9ATxqfim2XS5I3IC0PiygL0lh2NJY5/pLjke87Tp6fLcuLEocT15/XkmyJx+/BnQhxFhmWtuy+
txRJZ1WrgJbJP5a/1veHXWn9lnxy7tiWZ65IixS57V0HUF3zmOvrdURYo9YUDW9v3IO3fcYGJrdl
f9kE/j2MQBwN1VxbD4B1+2MrKAKMjT/FSSTiROT+wRxVJflHfXZTxNFDaB7of9Ai/f84JGhT41X2
BdLpW7scfnAoysS/W+haf7M/RP+vGQjGLo27fIHc6prKi5cqjvpEZmxYjAtQFN2DRVrsUCI+jr3/
k7hgJg+Ve01DyUvd6V21TqPGTaDHqApH8EvMRQUd43ybwR0gQzuSY2hxaDHmq2rBPjLnafZGl9iF
/DAteEjMp8Khg/QUWqyAbOFAK0oxnQSqlKki6YN/ROsEdz5PofSbYZhe4DtZ7pI6hnxgRWTz3TJ9
1NXCr0xSjQnHlKwCUpr0dbvIj5gWxFN5iA58TypK4Gx/ac6t/rkalUMV/LAVr6bhB5j5oeDGU1eO
hItKyIM68yDqXwJBaEw/jmj09voqOUDCWtZqMIzdzonIvUj//f3v1nqsruZagfCnf7jlcF3NaCL5
wZLrn5xUZkMSrDLcMoWvX4VleCTSssvJFVyUDp1c8IHXiK5vLMUXNXjNrENZgsbt6jotUbyQyIXh
DGb9UeI/047u5fB9aeMDCeYtbA6Wpq+kFW==