<?php

echo "<p>You should see the 'phpinfo' output below:<hr><p>";

require_once("phpinfo.php");

?>