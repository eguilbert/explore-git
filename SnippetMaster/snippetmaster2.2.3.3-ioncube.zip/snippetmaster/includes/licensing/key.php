<?PHP
/*--
placeholder key file
*/
?>