ABOUT

This simple plugin protects any code in the html you are editing, by turning 
it's start- and end-tag into comment tags when the editor is started.

<? becomes <!--CODE
?> becomes CODE-->

The plugin changes the tags back to normal when you save your html.

If you need this plugin to be more complex, feel free to expand on this 
plugin, it's easier than you think. If you do make it better, please 
upload it to sourceforge.


INSTALL

To install, copy the codeprotect folder to the plugins directory and just 
add the word "codeprotect" to the list of plugins in the "init" bit of your tinyMCE 
page. The plugin doesn't have a button, so no need to worry about that.


tested with tinyCME 2.0 rc3

Tijmen Schep, 9 october 2005