// HU lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Ez csak egy p�lda popup',
template_desc : 'Ez csak egy p�lda gomb'
});
