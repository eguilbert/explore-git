// NL lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Zoeken',
searchreplace_searchnext_desc : 'Opnieuw zoeken',
searchreplace_replace_desc : 'Zoeken/Vervangen',
searchreplace_notfound : 'Het doorzoeken van document is voltooid. De gezochte tekst is niet gevonden.',
searchreplace_search_title : 'Zoeken',
searchreplace_replace_title : 'Zoeken/Vervangen',
searchreplace_allreplaced : 'Alle zoekargumenten werden vervangen.',
searchreplace_findwhat : 'Zoeken naar',
searchreplace_replacewith : 'Vervangen door',
searchreplace_direction : 'Richting',
searchreplace_up : 'Omhoog',
searchreplace_down : 'Omlaag',
searchreplace_case : 'Identieke hoofdletters/kleine letters',
searchreplace_findnext : 'Volgende zoeken',
searchreplace_replace : 'Vervangen',
searchreplace_replaceall : 'Alles&nbsp;vervangen',
searchreplace_cancel : 'Annuleren'
});
