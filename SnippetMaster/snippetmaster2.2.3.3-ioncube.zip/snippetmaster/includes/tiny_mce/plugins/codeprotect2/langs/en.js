// UK lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'codeprotect settings',
template_desc : 'codeprotect',
codeprotect_button_desc : 'Template Code',
insert_codeprotect_title: 'Template Code Editor',
insert_codeprotect_name: 'Template Code'
});
