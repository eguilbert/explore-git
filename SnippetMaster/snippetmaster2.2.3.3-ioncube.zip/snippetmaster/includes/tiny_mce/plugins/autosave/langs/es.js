/**
 * ES lang variables
 * 
 * Authors : Alvaro Velasco,
 *           Adolfo Sanz De Diego (asanzdiego) <asanzdiego@yahoo.es>,
 *           Carlos C Soto (eclipxe) <csoto@sia-solutions.com>
 *           Eneko Castresana Vara
 * Last Updated : July 14, 2006
 * TinyMCE Version : 2.0.6.1
 */

tinyMCE.addToLang('',{
autosave_unload_msg : 'Los cambios que hayas hecho pueden perderse si navegas fuera de esta p&aacute;gina.'
});
