// NL lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'De gemaakte veranderingen zullen verloren gaan als u naar een andere pagina navigeert.'
});
