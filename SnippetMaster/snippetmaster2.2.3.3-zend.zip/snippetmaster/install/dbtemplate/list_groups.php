id#name#use_browse_list#browse_list_type#browse_list#use_links_list#links_list_type#links_list#use_images_list#images_list_type#images_list#description
inc#str#int#int#int#int#int#int#int#int#int#str
###########
1#List Group 1#0#1#1#0#1#1#0#1#1#This is the list group 1 description
