list_id#entry
int#str
#

1#cgi-bin
1#CGI-BIN
1#images
1#includes
1#stats
1#Templates
1#