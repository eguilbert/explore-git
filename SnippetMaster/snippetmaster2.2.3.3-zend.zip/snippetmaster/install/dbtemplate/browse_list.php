id#dummy
inc#str
#

1#