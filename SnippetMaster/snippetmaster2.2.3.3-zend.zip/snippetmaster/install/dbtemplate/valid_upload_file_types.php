list_id#file_type
int#str
#

1#doc
1#gif
1#jpg
1#jpeg
1#mp3
1#ods
1#odt
1#png
1#pdf
1#ppt
1#rar
1#rtf
1#xls
1#zip