list_id#number#name#path#overwrite
int#int#str#str#int
####
