id#name#description#limit_file_types#limit_file_size#file_size_limit#convert_uppercase_to_lower#disk_quota
inc#str#str#int#int#int#int#int
#######-1
1#Upload Group 1#This is the upload group 1 description#0#0##0#-1