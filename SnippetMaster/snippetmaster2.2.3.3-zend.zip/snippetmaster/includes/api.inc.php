<?php @Zend;
4123;
/*  �!This is not a text file!��   */
print <<<EOM
<html><body><a href="http://www.zend.com/products/zend_guard"><img border="0" src="http://www.zend.com/images/store/safeguard_optimizer_img.gif" align="right"></a><center><h1>Zend Optimizer not installed</h1></center><p>This file was encoded by the <a href="http://www.zend.com/products/zend_guard">Zend Guard</a>. In order to run it, please install the <a href="http://www.zend.com/products/zend_optimizer">Zend Optimizer</a> (available without charge), version 3.0.0 or later. </p><h2>Seeing this message instead of the website you expected?</h2>This means that this webserver is not configured correctly. In order to view this website properly, please contact the website's system administrator/webmaster with the following message:<br><br><tt>The component "Zend Optimizer" is not installed on the Web Server and therefore cannot service encoded files. Please download and install the Zend Optimizer (available without charge) on the Web Server.</tt><br><br><b>Note</b>: Zend Technologies cannot resolve issues related to this message appearing on websites not belonging to <a href="http://www.zend.com">Zend Technologies</a>. <h2>What is the Zend Optimizer?</h2><p>The Zend Optimizer is one of the most popular PHP plugins for performance-improvement, and has been available without charge, since the early days of PHP 4. It improves performance by scanning PHP's intermediate code and passing it through multiple Optimization Passes to replace inefficient code patterns with more efficient code blocks. The replaced code blocks perform exactly the same operations as the original code, only faster. </p><p>In addition to improving performance, the Zend Optimizer also enables PHP to transparently load files encoded by the Zend Guard. </p><p>The Zend Optimizer is a free product available for download from <a href="http://www.zend.com">Zend Technologies</a>. Zend Technologies also developed the PHP scripting engine, known as the <a href="http://www.zend.com/products/zend_engine">Zend Engine</a>.</p></body></html>
EOM;
exit();
__halt_compiler();
?>

2003120702 1 144 236 x�
�2&8cKSSKcx�(�47� �Z�נ�?�47�R/1%�ZM3#C^h
@�xy�.m�!mj�`�M�(��E �&�LK,Ȍ����,.��575262����朲Ē�x`3�[����������4`  7� �