// NL lang variables

tinyMCE.addToLang('emotions',{
title : 'Emoticon invoegen',
desc : 'Emoticons',
cool : 'Cool',
cry : 'Huilen',
embarassed : 'Verlegen', // embarrassed
foot_in_mouth : 'Eten in mond', // food in mouth?
frown : 'Fronsen',
innocent : 'Onschuldig',
kiss : 'Kus',
laughing : 'Lachend',
money_mouth : 'Geldgezicht',
sealed : 'Verzegeld',
smile : 'Smile',
surprised : 'Verbaasd',
tongue_out : 'Tong uitstekend',
undecided : 'Obepaald',
wink : 'Knipoog',
yell : 'Schreeuwen'
});
