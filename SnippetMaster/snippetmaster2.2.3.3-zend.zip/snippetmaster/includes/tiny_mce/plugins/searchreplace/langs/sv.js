// SE lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'S&ouml;k',
searchreplace_searchnext_desc : 'S&ouml;k igen',
searchreplace_replace_desc : 'S&ouml;k/Ers&auml;tt',
searchreplace_notfound : 'S&ouml;kningen &auml;r slutf&ouml;rd. S&ouml;kstr&auml;ngen kunde inte hittas.',
searchreplace_search_title : 'S&ouml;k',
searchreplace_replace_title : 'S&ouml;k/Ers&auml;tt',
searchreplace_allreplaced : 'Alla tr&auml;ffar p&aring; s&ouml;kstr&auml;ngen ersattes',
searchreplace_findwhat : 'S&ouml;k p&aring;',
searchreplace_replacewith : 'Ers&auml;tt med',
searchreplace_direction : 'S&ouml;kriktning',
searchreplace_up : 'Upp&aring;t',
searchreplace_down : 'Ner&aring;t',
searchreplace_case : 'Matcha gemener/VERSALER',
searchreplace_findnext : 'S&ouml;k&nbsp;n&auml;sta',
searchreplace_replace : 'Ers&auml;tt',
searchreplace_replaceall : 'Ers&auml;tt&nbsp;alla',
searchreplace_cancel : 'Avbryt'
});
