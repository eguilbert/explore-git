// UK lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%d-%m-%Y',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Datum invoegen',
inserttime_desc : 'Tijd invoegen',
inserttime_months_long : new Array("januari", "februari", "maart", "april", "mei", "juni", "juli", "augustus", "september", "oktober", "november", "december"),
inserttime_months_short : new Array("jan", "feb", "mrt", "apr", "mei", "jun", "jul", "aug", "sep", "oct", "nov", "dec"),
inserttime_day_long : new Array("zondag", "maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag", "zondag"),
inserttime_day_short : new Array("zo", "ma", "di", "wo", "do", "vr", "za", "zo")
});
